var randomScalingFactor = function(){ return Math.round(Math.random()*10000)};
	
	// var lineChartData = {
	// 	labels : ["January","February","March","April","May","June","July"],
	// 	datasets : [
	// 		{
	// 			label: "My First dataset",
	// 			fillColor : "rgba(48, 164, 255, 0)",
	// 			strokeColor : "rgba(48, 164, 255, 1)",
	// 			pointColor : "rgba(48, 164, 255, 1)",
	// 			pointStrokeColor : "#fff",
	// 			pointHighlightFill : "#fff",
	// 			pointHighlightStroke : "rgba(220,220,220,1)",
	// 			data : [5000,4000,5000,4000,5000,4000,5000]
	// 		},
	// 		{
	// 			label: "My Second dataset",
	// 			fillColor : "rgba(255, 181, 62, 0)",
	// 			strokeColor : "rgba(255, 181, 62, 1)",
	// 			pointColor : "rgba(255, 181, 62, 1)",
	// 			pointStrokeColor : "#fff",
	// 			pointStrokeColor : "#fff",
	// 			pointHighlightFill : "#fff",
	// 			pointHighlightStroke : "rgba(48, 164, 255, 1)",
	// 			data : [4000,5000,4000,5000,4000,5000,4000]
	// 		},
	// 		{
	// 			label: "My Third dataset",
	// 			fillColor : "rgba(30,191,174,0)",			
	// 			strokeColor : "rgba(30,191,174,1)",
	// 			pointColor : "rgba(30,191,174,1)",
	// 			pointStrokeColor : "#fff",
	// 			pointHighlightFill : "#fff",
	// 			pointHighlightStroke : "rgba(48, 164, 255, 1)",
	// 			data : [3000,3000,3000,3000,3000,3000,3000]
	// 		},
	// 		{
	// 			label: "My Fourth dataset",
	// 			fillColor : "rgba(239, 64, 64, 0)",
	// 			strokeColor : "rgba(239, 64, 64, 1",
	// 			pointColor : "rgba(239, 64, 64, 1)",
	// 			pointStrokeColor : "#fff",
	// 			pointHighlightFill : "#fff",
	// 			pointHighlightStroke : "rgba(48, 164, 255, 1)",
	// 			data : [2000,2000,2000,2000,2000,2000,2000]
	// 		}
	// 	]

	// }
		
	

	// var pieData = [
	// 		{
	// 			value: 300,
	// 			color:"#30a5ff",
	// 			highlight: "#62b9fb",
	// 			label: "Blue"
	// 		},
	// 		{
	// 			value: 50,
	// 			color: "#ffb53e",
	// 			highlight: "#fac878",
	// 			label: "Orange"
	// 		},
	// 		{
	// 			value: 100,
	// 			color: "#1ebfae",
	// 			highlight: "#3cdfce",
	// 			label: "Teal"
	// 		},
	// 		{
	// 			value: 120,
	// 			color: "#f9243f",
	// 			highlight: "#f6495f",
	// 			label: "Red"
	// 		}

	// 	];
			
	
			
	

