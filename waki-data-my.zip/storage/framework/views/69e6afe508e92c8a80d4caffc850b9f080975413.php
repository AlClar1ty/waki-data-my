<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'WAKi DATA')); ?></title>

    <!-- Styles, Font, Bootstrap, Icon -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/material-icons.min.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="<?php echo e(asset('css/Contact-Form-Clean.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Navigation-with-Button.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Sidebar-Menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Sidebar-Menu1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    
</head>
<body style="background-image:url(&quot;<?php echo e(asset('img/BG-01.png')); ?>&quot;);">
    <div id="app">
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo e(asset('js/ListMethod.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Sidebar-Menu.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
