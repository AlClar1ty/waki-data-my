<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="contact-clean" style="position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);width:360px;">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="margin-bottom:40px;"><img src="<?php echo e(asset('img/waki.png')); ?>" style="width:100%;"></div>
            <h4 class="text-center">WAKi DATA</h4>
            <div class="form-group">
                <input id="username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" type="text" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>" required autofocus style='text-transform:uppercase;'>

                <?php if($errors->has('username')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <input id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" name="password" placeholder="PASSWORD" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group"><button class="btn btn-primary btn-block" type="submit">LOGIN</button></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>